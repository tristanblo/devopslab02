# msc-se-devops-2021
MSc Software Engineering (UvA) - DevOps and Cloud-based Software (2020-2021) | Repo for Lab assignments | Group "devops08" 
